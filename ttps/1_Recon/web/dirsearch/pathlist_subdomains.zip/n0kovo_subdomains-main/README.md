# n0kovo_subdomains wordlist
An extremely effective subdomain enumeration wordlist of 3,000,000 lines, crafted by harvesting SSL certs from the entire IPv4 space.

I have written a lengthy article on the creation of this list, go read it [here](https://n0kovo.github.io/posts/subdomain-enumeration-creating-a-highly-efficient-wordlist-by-scanning-the-entire-internet/). <br><br>

Size vs. Hits comparison: <br>
<img src="https://user-images.githubusercontent.com/16690056/229874953-3454208f-6ecc-4fbc-a973-5cd04bd6082d.png" data-canonical-src="https://user-images.githubusercontent.com/16690056/229874953-3454208f-6ecc-4fbc-a973-5cd04bd6082d.png" width="600"/>

<img src="https://user-images.githubusercontent.com/16690056/229874921-68e5c347-2cf3-4d11-a0c8-bd2118f29261.png" data-canonical-src="https://user-images.githubusercontent.com/16690056/229874921-68e5c347-2cf3-4d11-a0c8-bd2118f29261.png" width="600"/>
